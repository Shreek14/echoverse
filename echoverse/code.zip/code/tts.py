# tts_runner.py
from ibm_watson import TextToSpeechV1
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

# --- IBM TTS setup ---
API_KEY = "Qkhw_mmE9bPpKDPQui52K8Loz4M76KNz9JZNh9ry013p"
URL = "https://api.eu-de.text-to-speech.watson.cloud.ibm.com"

authenticator = IAMAuthenticator(API_KEY)
tts_service = TextToSpeechV1(authenticator=authenticator)
tts_service.set_service_url(URL)


def generate_tts(
    emotion_objects,
    output_file="output_audio.mp3",
    voice="en-US_AllisonV3Voice",
):
    """
    Convert text (emotion_objects) to speech and save as a single audio file.
    """
    # Combine all text with small pauses
    combined_text = ". ".join([obj["speech_text"] for obj in emotion_objects])
    
    # Generate single audio file
    response = tts_service.synthesize(
        combined_text,
        voice=voice,
        accept="audio/mp3"
    ).get_result()
    
    with open(output_file, "wb") as audio_file:
        audio_file.write(response.content)

    print(f"Audio saved as {output_file}")
    return output_file